//! Training jobs: in-memory state machine + tokio task lifecycle.
//!
//! The UI submits a `TrainingJob` via `POST /api/train/start`; the server
//! hands the job id to a worker task and reports status through:
//!   - `GET   /api/train/status/:id`   — single snapshot
//!   - `SSE   /sse/metrics/:id`        — live loss/vram telemetry
//!
//! Workers record per-step metrics into `job.metrics` as they run; the
//! `metrics_watcher` emits each new metric to subscribed SSE clients via
//! a `tokio::sync::broadcast` channel.

use std::collections::HashMap;
use std::sync::Arc;

use grim_autograd::preference_loss::{
    dpo_loss, grpo_loss, grpo_normalize_rewards, kto_loss, orpo_odds_ratio_loss, simpo_loss,
};
use grim_tensor::{DType, QuantProvenance, Shape, Tensor};
use serde::{Deserialize, Serialize};
use thiserror::Error;
use tokio::sync::{RwLock, broadcast};
use tokio_util::sync::CancellationToken;
use uuid::Uuid;

#[derive(Debug, Error)]
pub enum JobError {
    #[error("job not found: {0}")]
    NotFound(String),
    #[error("duplicate job id")]
    Duplicate,
}

/// Coarse job status surface — enough for the UI badge in the history list.
///
/// Wire format is lowercase (e.g. `"cancelled"`) for consistency with the
/// `status_label` seam used by `/api/train/jobs` and `/api/train/status`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum JobStatus {
    Pending,
    Running,
    Completed,
    Failed,
    /// User requested cancellation via `POST /api/train/cancel/{id}`.
    Cancelled,
}

impl Default for JobStatus {
    fn default() -> Self {
        JobStatus::Pending
    }
}

/// Training mode the UI's "Training Mode" dropdown drives.
///
/// SFT modes: `Lora`, `QLoRA`, `Bf16Full`, `RsLora`, `Dora`, `LoftQ`, `SoulEater`.
/// Reinforcement-learning modes: `Orpo`, `Dpo`, `Kto`, `SimPo`, `Grpo`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TrainingMode {
    /// LoRA supervised fine-tuning on compressed weights.
    Lora,
    /// Quantized LoRA — LoRA adapters with block-quantized base weights.
    QLoRA,
    /// Full BF16 supervised fine-tuning (unpacked weights).
    Bf16Full,
    /// Rank-Stabilized LoRA — scaling factor γ = α / √r for stable gradients.
    RsLora,
    /// Weight-Decomposed LoRA — decouples magnitude and direction for better conditioning.
    Dora,
    /// LoftQ — SVD quantization-aware adapter initialization.
    LoftQ,
    /// Odds-Ratio Preference Optimization (HLRF reinforcement).
    Orpo,
    /// Direct Preference Optimization (HLRF reinforcement).
    Dpo,
    /// Kahneman-Tversky Optimization (binary feedback, no reference model).
    Kto,
    /// Simple Preference Optimization (length-normalized, no reference model).
    SimPo,
    /// Group Relative Policy Optimization (RLHF-style clipped surrogate).
    Grpo,
    /// SOUL EATER adapter + Muon-style optimizer (Newton-Schulz + Sign-SGD).
    SoulEater,
}

/// One per-step metric sample: step id, loss, tokens processed.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Metric {
    pub step: u64,
    pub loss: f64,
    pub tokens: u64,
    pub grad_norm: f32,
    pub lr: f32,
    pub vram_used_mb: u32,
    pub samples_per_sec: f32,
}

/// Configuration for a training job — what the React UI submits verbatim.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrainingJob {
    pub model_path: String,
    pub dataset_path: String,
    pub training_mode: TrainingMode,
    pub lora_rank: u32,
    pub learning_rate: f64,
    pub epochs: u32,
    pub rocm_fusion_rmsnorm_matmul: bool,
    pub rocm_fusion_qkv_attention: bool,
    /// Codec format for base weights: Bf16, Crow, Raven, Rook, Jay, Jackdaw, Magpie.
    #[serde(default)]
    pub weight_format: crate::weight_format::WeightFormat,
    /// Backend the user selected for this job. `None` = auto (top of the
    /// ROCm→CUDA→Vulkan→Metal→CPU priority chain that is actually live).
    #[serde(default)]
    pub preferred_backend: Option<String>,
    /// Gradient accumulation steps. Optimizer step fires every N micro-steps;
    /// loss is reported as the average over the accumulation window.
    #[serde(default = "default_accumulation_steps")]
    pub accumulation_steps: u32,
    /// Which optimizer to use for this training job.
    #[serde(default)]
    pub optimizer: grim_autograd::OptimizerKind,
    /// Which LR schedule to use. Default is `Cosine` (=cosine-with-warmup).
    #[serde(default)]
    pub scheduler: grim_autograd::LRScheduler,
    /// Minimum LR for cosine/polynomial/linear schedules.
    #[serde(default)]
    pub min_lr: f64,
    /// Number of GPUs for data-parallel training. 0 or 1 = single GPU;
    /// >1 = RCCL all-reduce across N devices.
    #[serde(default)]
    pub num_gpus: u32,
    /// PiSSA: initialize adapter A/B via truncated SVD of the base weight
    /// (principal singular components) instead of Kaiming-style random init.
    #[serde(default)]
    pub use_pissa: bool,
    /// OLoRA: add `olora_lambda * olora_orthogonality_penalty(A, B)` to the loss.
    #[serde(default)]
    pub use_olora: bool,
    /// Weight of the OLoRA orthogonality penalty term. Only applied when
    /// `use_olora` is set and `olora_lambda > 0.0`.
    #[serde(default)]
    pub olora_lambda: f32,
    /// Optionally resume training from a checkpoint sidecar produced by a
    /// prior run.
    #[serde(default)]
    pub resume_from_checkpoint: Option<String>,
    /// Mutable state shared with the worker task.
    #[serde(skip)]
    pub status: JobStatus,
    #[serde(skip)]
    pub metrics: Vec<Metric>,
    /// Cancellation signal. `POST /api/train/cancel/{id}` triggers it; the
    /// running worker observes it inside its step loop and exits cleanly.
    /// Cloning a `CancellationToken` is cheap (one `Arc` bump).
    #[serde(skip)]
    pub cancel: CancellationToken,
}

fn default_accumulation_steps() -> u32 {
    1
}

impl Default for TrainingJob {
    fn default() -> Self {
        Self {
            model_path: String::new(),
            dataset_path: String::new(),
            training_mode: TrainingMode::Lora,
            lora_rank: 16,
            learning_rate: 2e-5,
            epochs: 1,
            rocm_fusion_rmsnorm_matmul: false,
            rocm_fusion_qkv_attention: false,
            weight_format: Default::default(),
            preferred_backend: None,
            accumulation_steps: 1,
            optimizer: grim_autograd::OptimizerKind::AdamW,
            scheduler: grim_autograd::LRScheduler::Cosine,
            min_lr: 2e-7, // 1% of default learning rate 2e-5
            num_gpus: 0,
            use_pissa: false,
            use_olora: false,
            olora_lambda: 0.0,
            resume_from_checkpoint: None,
            status: JobStatus::Pending,
            metrics: Vec::new(),
            cancel: CancellationToken::new(),
        }
    }
}

impl TrainingJob {
    /// Append a metric sample. Used by worker tasks and by tests.
    pub fn push_metric(&mut self, step: u64, loss: f64, tokens: u64) {
        self.metrics.push(Metric {
            step,
            loss,
            tokens,
            grad_norm: 0.0,
            lr: 0.0,
            vram_used_mb: 0,
            samples_per_sec: 0.0,
        });
    }
}

/// Strongly typed UUID wrapper.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct JobId(pub String);

impl JobId {
    pub fn new() -> Self {
        Self(Uuid::new_v4().to_string())
    }
}

impl Default for JobId {
    fn default() -> Self {
        Self::new()
    }
}

impl std::fmt::Display for JobId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.0)
    }
}

/// Live metric stream sent to SSE subscribers.
#[derive(Debug, Clone, Serialize)]
pub struct MetricStreamEvent {
    pub job_id: String,
    pub metric: Metric,
    pub status: JobStatus,
}

/// In-memory registry of training jobs. Shared via `Arc<RwLock<_>>` between
/// the HTTP server and the worker tasks that update metrics.
#[derive(Debug)]
pub struct JobRegistry {
    inner: Arc<RwLock<HashMap<JobId, TrainingJob>>>,
    metrics_tx: broadcast::Sender<MetricStreamEvent>,
    pub max_concurrent: usize,
}

impl Default for JobRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl JobRegistry {
    pub fn new() -> Self {
        let max_concurrent = std::env::var("GRIM_MAX_CONCURRENT_JOBS")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(4);
        Self::with_max_concurrent(max_concurrent)
    }

    pub fn with_max_concurrent(max_concurrent: usize) -> Self {
        let (metrics_tx, _) = broadcast::channel(1024);
        Self {
            inner: Arc::new(RwLock::new(HashMap::new())),
            metrics_tx,
            max_concurrent,
        }
    }

    /// Count jobs that are currently Running or Pending.
    pub async fn running_count(&self) -> usize {
        let g = self.inner.read().await;
        g.values()
            .filter(|j| matches!(j.status, JobStatus::Pending | JobStatus::Running))
            .count()
    }

    /// Create a new job with a freshly-generated id. Stored as `Pending`.
    /// Returns the new id so the caller can hand it back to the UI immediately.
    pub async fn create(&self, job: TrainingJob) -> Result<JobId, JobError> {
        let id = JobId::new();
        let mut g = self.inner.write().await;
        g.insert(id.clone(), job);
        Ok(id)
    }

    /// Insert with an explicit id. Used by tests to verify duplicate rejection.
    pub async fn insert_with_id(&self, id: JobId, job: TrainingJob) -> Result<JobId, JobError> {
        let mut g = self.inner.write().await;
        if g.contains_key(&id) {
            return Err(JobError::Duplicate);
        }
        g.insert(id.clone(), job);
        Ok(id)
    }

    pub async fn get(&self, id: &JobId) -> Option<TrainingJob> {
        let g = self.inner.read().await;
        g.get(id).cloned()
    }

    pub async fn list(&self) -> Vec<(JobId, JobStatus)> {
        let g = self.inner.read().await;
        g.iter()
            .map(|(k, v)| (k.clone(), v.status))
            .collect::<Vec<_>>()
    }

    /// L5 / H5: enumerate job id + status + (cloned) job under a single
    /// read lock. Replaces the previous N+1 pattern where the route called
    /// `list()` to get `(id, status)` pairs and then re-`get()`'d each id
    /// afterward — that two-step pattern had a race window between the
    /// two locks during which a job could be evicted, and the route
    /// responded with empty `model_path`/`dataset_path` ("ghost"
    /// JobSummary rows that surfaced as blank cards in the UI).
    pub async fn snapshot(&self) -> Vec<(JobId, JobStatus, TrainingJob)> {
        let g = self.inner.read().await;
        g.iter()
            .map(|(k, v)| (k.clone(), v.status, v.clone()))
            .collect::<Vec<_>>()
    }

    pub async fn update_status(&self, id: &JobId, status: JobStatus) -> Result<(), JobError> {
        let mut g = self.inner.write().await;
        let job = g
            .get_mut(id)
            .ok_or_else(|| JobError::NotFound(id.0.clone()))?;
        job.status = status;
        Ok(())
    }

    /// Transition a job to `status` **and** broadcast a terminal
    /// `MetricStreamEvent` carrying the post-transition status so SSE
    /// subscribers receive a guaranteed terminal event. This is the
    /// counterpart to `append_metric`'s per-step broadcast; without it,
    /// `Completed`/`Failed`/`Cancelled` transitions are silent on the
    /// live stream and subscribers only learn them via polling.
    ///
    /// Returns the metric that was broadcast (the job's last recorded
    /// step, or a zero-step sentinel when none has been recorded yet)
    /// so callers may decide to skip a redundant immediate append.
    pub async fn update_status_and_broadcast(
        &self,
        id: &JobId,
        status: JobStatus,
    ) -> Result<Metric, JobError> {
        let mut g = self.inner.write().await;
        let job = g
            .get_mut(id)
            .ok_or_else(|| JobError::NotFound(id.0.clone()))?;
        job.status = status;
        // Use the last recorded metric if present; otherwise synthesize a
        // zero-step sentinel so the SSE payload shape stays uniform.
        let metric = job.metrics.last().cloned().unwrap_or(Metric {
            step: 0,
            loss: 0.0,
            tokens: 0,
            grad_norm: 0.0,
            lr: 0.0,
            vram_used_mb: 0,
            samples_per_sec: 0.0,
        });
        // Best-effort broadcast; if there are no SSE subscribers this is Err
        // and we ignore — the next subscriber gets a snapshot via the
        // initial metrics replay in `sse_metrics`.
        let _ = self.metrics_tx.send(MetricStreamEvent {
            job_id: id.0.clone(),
            metric: metric.clone(),
            status,
        });
        Ok(metric)
    }

    /// Request cancellation of a running worker. Idempotent with respect to
    /// the cancellation token — calling twice is harmless. Returns
    /// `NotFound` if the job id is not in the registry so the caller can
    /// surface a 404. The caller is responsible for setting the resulting
    /// wire status; this method only signals the worker.
    pub async fn cancel(&self, id: &JobId) -> Result<(), JobError> {
        let g = self.inner.read().await;
        let job = g.get(id).ok_or_else(|| JobError::NotFound(id.0.clone()))?;
        job.cancel.cancel();
        Ok(())
    }

    /// Atomic cancel request + terminal-status transition. Entry-point for
    /// the `POST /api/train/cancel/{id}` route: under a single write lock,
    /// (a) triggers the job's `CancellationToken` so the running worker's
    /// `select!` arm exits on the next iteration, and (b) transitions the
    /// registry status to `Cancelled` **only if the job is still
    /// non-terminal** (Pending or Running). If the job already reached
    /// `Completed`/`Failed` — the cancel arrived after the worker finished —
    /// the existing terminal status is preserved and the response reflects
    /// reality rather than overwriting it.
    ///
    /// Broadcasts a terminal `MetricStreamEvent { status: Cancelled }`
    /// when it does transition, so SSE subscribers learn about the cancel
    /// without polling.
    pub async fn request_cancel(&self, id: &JobId) -> Result<JobStatus, JobError> {
        let mut g = self.inner.write().await;
        let job = g
            .get_mut(id)
            .ok_or_else(|| JobError::NotFound(id.0.clone()))?;
        job.cancel.cancel();
        let current = job.status;
        if matches!(current, JobStatus::Pending | JobStatus::Running) {
            job.status = JobStatus::Cancelled;
            // Broadcast a terminal event (best-effort: no subscribers = Err).
            let metric = job.metrics.last().cloned().unwrap_or(Metric {
                step: 0,
                loss: 0.0,
                tokens: 0,
                grad_norm: 0.0,
                lr: 0.0,
                vram_used_mb: 0,
                samples_per_sec: 0.0,
            });
            let _ = self.metrics_tx.send(MetricStreamEvent {
                job_id: id.0.clone(),
                metric,
                status: JobStatus::Cancelled,
            });
            Ok(JobStatus::Cancelled)
        } else {
            // Already terminal (Completed/Failed/Cancelled) — leave it.
            Ok(current)
        }
    }

    pub async fn append_metric(&self, id: &JobId, metric: Metric) -> Result<(), JobError> {
        let mut g = self.inner.write().await;
        let job = g
            .get_mut(id)
            .ok_or_else(|| JobError::NotFound(id.0.clone()))?;
        let status = job.status;
        job.push_metric(metric.step, metric.loss, metric.tokens);
        // Best-effort broadcast; if there are no subscribers (SSE clients) this returns Err
        // and we just ignore — the next subscriber would need a snapshot via /api/train/status.
        let _ = self.metrics_tx.send(MetricStreamEvent {
            job_id: id.0.clone(),
            metric,
            status,
        });
        Ok(())
    }

    /// Subscribe to the live metric stream. Each subscriber gets every subsequent event.
    pub fn subscribe_metrics(&self) -> broadcast::Receiver<MetricStreamEvent> {
        self.metrics_tx.subscribe()
    }
}

/// Compute a baseline loss for the given training mode.
///
/// SFT modes start from an empirical cross-entropy target (~2.3);
/// RL modes use an initial reward differential of 0.0 converging upward.
fn initial_loss(mode: TrainingMode) -> f64 {
    match mode {
        TrainingMode::Lora | TrainingMode::QLoRA | TrainingMode::Bf16Full => 2.3,
        TrainingMode::RsLora
        | TrainingMode::Dora
        | TrainingMode::LoftQ
        | TrainingMode::SoulEater => 2.3,
        TrainingMode::Orpo
        | TrainingMode::Dpo
        | TrainingMode::Kto
        | TrainingMode::SimPo
        | TrainingMode::Grpo => 0.0,
    }
}

/// Sum the OLoRA orthogonality penalty over every enabled adapter whose
/// config has `use_olora` with `olora_lambda > 0.0`, returning
/// `Σ olora_lambda · olora_orthogonality_penalty(a, b)`.
///
/// Shape note: `olora_orthogonality_penalty(a, b)` expects `a` = `[out, r]`
/// (down-projection) and `b` = `[r, in]` (up-projection). The registry stores
/// A = `[r, in]` and B = `[out, r]`, so we pass B as `a` and A as `b`.
///
/// Host-computed (off the tape): the penalty is added to the scalar loss
/// before `backward()` per the OLoRA plan, matching `olora_orthogonality_penalty`.
fn olora_penalty_for_registry(reg: &grim_autograd::registry::AutogradRegistry) -> f32 {
    let mut total = 0.0f32;
    for cfg in reg.injection_registry.enabled() {
        if cfg.use_olora && cfg.olora_lambda > 0.0 {
            if let (Some(param_b), Some(param_a)) = (
                reg.params.get(cfg.param_id_b()),
                reg.params.get(cfg.param_id_a()),
            ) {
                if let Ok(pen) =
                    grim_autograd::olora_orthogonality_penalty(&param_b.data, &param_a.data)
                {
                    total += cfg.olora_lambda * pen;
                }
            }
        }
    }
    total
}

/// Execute a training job inside a Tokio background task.
///
/// The caller should spawn this with `tokio::spawn`:
/// ```rust,no_run
/// # use std::sync::Arc;
/// # use grim_garage::jobs::{JobId, JobRegistry, run_training_worker};
/// # async fn example(registry: Arc<JobRegistry>, job_id: JobId) {
/// tokio::spawn(run_training_worker(registry.clone(), job_id));
/// # }
/// ```
///
/// Contract:
/// - Transitions `Pending → Running` immediately.
/// - Emits one `Metric` event per training step.
/// - On completion, transitions to `Completed` and broadcasts a terminal
///   `MetricStreamEvent { status = Completed }` to SSE subscribers.
/// - On cancellation (via `JobRegistry::cancel`), exits the step loop
///   without writing the sidecar and transitions to `Cancelled`, also
///   broadcasting a terminal event.
/// - On any registry error, transitions to `Failed` + broadcasts and logs.

/// Read model hyperparameters from a GGUF file via `HyperparameterExtractor`.
///
/// Implements `MetadataLookup` over a parsed `GgufFile` and resolves the
/// architecture from the `general.architecture` key. Returns `None` when the
/// path isn't a readable GGUF (caller falls back to default hyperparams).
fn read_model_hyperparams(model_path: &str) -> Option<grim_core::hyperparams::ArchHyperparameters> {
    use grim_core::hyperparams::{HyperparameterExtractor, MetadataLookup};
    use std::fs::File;
    use std::io::BufReader;

    /// Adapter that implements `MetadataLookup` over a `GgufFile`'s metadata
    /// HashMap — the same trait the inference engine's model loader uses.
    struct GgufMetaLookup(std::collections::HashMap<String, grim_format::gguf::GgufValue>);

    impl MetadataLookup for GgufMetaLookup {
        fn get_str(&self, key: &str) -> Option<String> {
            self.0
                .get(key)
                .and_then(|v| v.as_str().map(|s| s.to_string()))
        }
        fn get_u32(&self, key: &str) -> Option<u32> {
            self.0.get(key).and_then(|v| v.as_u32())
        }
        fn get_f32(&self, key: &str) -> Option<f32> {
            self.0.get(key).and_then(|v| v.as_f32())
        }
    }

    let file = File::open(model_path).ok()?;
    let mut reader = BufReader::new(file);
    let gguf = grim_format::gguf::read_gguf(&mut reader).ok()?;
    let arch_str = gguf
        .metadata
        .get("general.architecture")
        .and_then(|v| v.as_str())?;
    let arch = grim_core::architecture::ModelArchitecture::from_str(arch_str);
    let lookup = GgufMetaLookup(gguf.metadata);
    Some(HyperparameterExtractor::extract(arch, &lookup))
}

pub async fn run_training_worker(registry: Arc<JobRegistry>, id: JobId) {
    // Retrieve the job configuration.
    let job = match registry.get(&id).await {
        Some(j) => j,
        None => {
            eprintln!("[grim-garage] worker: job {} not found — aborting", id);
            return;
        }
    };

    let mode = job.training_mode;
    let epochs = job.epochs.max(1) as u64;
    // Derive steps per epoch from the dataset size when available; otherwise
    // default to a conservative 100 steps. The previous code hardcoded 10,
    // which under-trained on real datasets. We estimate the dataset length
    // by counting lines (each JSONL line ≈ one training example); the
    // dataloader packs `batch_size` sequences per step, so
    // steps_per_epoch ≈ line_count / batch_size.
    let batch_size = 1usize;
    let steps_per_epoch: u64 = if !job.dataset_path.is_empty() {
        use std::io::BufRead;
        match std::fs::File::open(&job.dataset_path) {
            Ok(f) => {
                let line_count = std::io::BufReader::new(f).lines().count();
                ((line_count / batch_size).max(1)) as u64
            }
            Err(_) => 100,
        }
    } else {
        100
    };
    let total_steps = epochs * steps_per_epoch;

    // Restore optimizer step from checkpoint if resuming.
    let mut step_counter: u64 = 0;
    if let Some(ref cp_path) = job.resume_from_checkpoint {
        if let Ok(Some(state)) = grim_format::train::TrainState::read(cp_path) {
            step_counter = state.step;
            eprintln!(
                "[grim-garage] worker: {} resuming from step {}",
                id, step_counter
            );
        }
    }

    // Cancellation token shared with the registry's `cancel` API. Cloned
    // here so we don't need to re-read the job mid-run; `cancelled()` is
    // satisfied when `cancel.cancel()` fires from another task.
    let cancel = job.cancel.clone();

    // Select the compute backend for this job from the user's preference,
    // falling through the ROCm→CUDA→Vulkan→Metal→CPU priority chain. This is
    // the single source of truth for where steps actually run — tensors are
    // created on this device, so the autograd tape dispatches to it.
    let preferred = job
        .preferred_backend
        .as_deref()
        .map(crate::backend::PreferredBackend::from_str_opt);
    let backend = crate::backend::select_backend(preferred.clone());
    eprintln!(
        "[grim-garage] worker: job {} selected backend '{}' (preferred={:?})",
        id,
        backend.label,
        preferred.unwrap_or(crate::backend::PreferredBackend::Auto)
    );

    // Transition → Running (no broadcast: per-step events arrive shortly).
    if let Err(e) = registry.update_status(&id, JobStatus::Running).await {
        eprintln!("[grim-garage] worker: failed to mark {} Running: {e}", id);
        return;
    }
    eprintln!(
        "[grim-garage] worker: job {} started (mode={mode:?}, epochs={epochs}, backend={})",
        id, backend.label
    );

    // SCYTHE-2 WI-6: RCCL all-reduce handle for multi-GPU gradient sync.
    // Constructed once per job; when num_gpus <= 1 the handle is None and
    // all_reduce_grads falls back to the CPU-only accumulate path.
    let rccl_handle = if job.num_gpus > 1 && backend.label == "rocm" {
        Some(grim_backend_rocm::RcclAllReduce::new(job.num_gpus as u32))
    } else {
        None
    };

    use grim_autograd::{
        AutogradRegistry, AutogradScope, InjectionConfig, LoRAInjectionPoint,
        LoRAInjectionRegistry, Tape, backward, cross_entropy_loss,
    };

    let lora_rank = job.lora_rank as usize;

    // Read real model hyperparameters from the GGUF file at `model_path`
    // rather than hardcoding 4096/32000/1/11008. This uses the same
    // `HyperparameterExtractor` the inference engine uses, so training and
    // inference agree on the model's shape. If the file isn't a readable
    // GGUF (e.g. a safetensors-only model without a config), fall back to
    // the `ArchHyperparameters::default()` (a 7B-class Llama) so the worker
    // still runs — but log the fallback so it's not silent.
    let hparams = read_model_hyperparams(&job.model_path).unwrap_or_else(|| {
        eprintln!(
            "[grim-garage] worker: could not read GGUF hyperparams from {}; \
             falling back to default 7B-class config (hidden=4096, layers=32)",
            job.model_path
        );
        grim_core::hyperparams::ArchHyperparameters::default()
    });
    let hidden_size = hparams.hidden_size;
    let vocab_size = hparams.vocab_size;
    let num_layers = hparams.num_layers;

    // Training modes that need the real base model for forward passes:
    // SFT modes for cross-entropy loss, RL modes for preference log-probs.
    let needs_model = matches!(
        mode,
        TrainingMode::Lora
            | TrainingMode::QLoRA
            | TrainingMode::Bf16Full
            | TrainingMode::RsLora
            | TrainingMode::Dora
            | TrainingMode::LoftQ
            | TrainingMode::SoulEater
            | TrainingMode::Dpo
            | TrainingMode::Orpo
            | TrainingMode::Kto
            | TrainingMode::SimPo
            | TrainingMode::Grpo
    );
    let mut sft_base: Option<(
        grim_format::GgufProvider,
        grim_nn::Embedding,
        grim_nn::RmsNorm,
        grim_nn::Linear,
        grim_engine::streaming_forward::StreamingBlockForward,
        grim_models_transformer::LlamaConfig,
    )> = None;
    if needs_model {
        match grim_format::GgufProvider::open(&job.model_path) {
            Ok(provider) => {
                // Load the head once per job. The per-layer weights are
                // streamed inside `forward_block_with_autograd` (which builds
                // its own WeightSource per block), matching the CLI trainer.
                let ws = grim_nn::WeightSource::root(&provider, backend.device.clone());
                let head = (|| -> Result<(grim_nn::Embedding, grim_nn::RmsNorm, grim_nn::Linear, grim_models_transformer::LlamaConfig), String> {
                    let tok_embeddings =
                        grim_nn::Embedding::load(&ws.pp("token_embd"), vocab_size, hidden_size)
                            .map_err(|e| format!("token_embd load failed: {e}"))?;
                    let output_norm =
                        grim_nn::RmsNorm::load(&ws.pp("output_norm"), hidden_size, hparams.rms_norm_eps)
                            .map_err(|e| format!("output_norm load failed: {e}"))?;
                    let lm_head = match grim_nn::Linear::load(
                        &ws.pp("output"),
                        hidden_size,
                        vocab_size,
                        false,
                    ) {
                        Ok(l) => l,
                        Err(_) => grim_nn::Linear::from_tensor(tok_embeddings.weight().clone(), None),
                    };
                    let llama_cfg = grim_models_transformer::LlamaConfig {
                        vocab_size: hparams.vocab_size,
                        hidden_size: hparams.hidden_size,
                        num_heads: hparams.num_heads,
                        num_kv_heads: hparams.num_kv_heads,
                        head_dim: hparams.head_dim,
                        num_layers: hparams.num_layers,
                        intermediate_size: hparams.intermediate_size,
                        rms_norm_eps: hparams.rms_norm_eps,
                        rope_theta: hparams.rope_theta,
                        max_seq_len: hparams.max_seq_len,
                    };
                    Ok((tok_embeddings, output_norm, lm_head, llama_cfg))
                })();
                match head {
                    Ok((tok_embeddings, output_norm, lm_head, llama_cfg)) => {
                        sft_base = Some((
                            provider,
                            tok_embeddings,
                            output_norm,
                            lm_head,
                            grim_engine::streaming_forward::StreamingBlockForward::new(
                                num_layers,
                                hidden_size,
                            ),
                            llama_cfg,
                        ));
                        eprintln!(
                            "[grim-garage] worker: {} loaded real base model (layers={num_layers}, hidden={hidden_size})",
                            id
                        );
                    }
                    Err(e) => {
                        eprintln!(
                            "[grim-garage] worker: {} failed to load real base model from {}: {e}",
                            id, job.model_path
                        );
                        let _ = registry
                            .update_status_and_broadcast(&id, JobStatus::Failed)
                            .await;
                        return;
                    }
                }
            }
            Err(e) => {
                eprintln!(
                    "[grim-garage] worker: {} cannot open model '{}': {e} — SFT modes require a readable GGUF model",
                    id, job.model_path
                );
                let _ = registry
                    .update_status_and_broadcast(&id, JobStatus::Failed)
                    .await;
                return;
            }
        }
    }

    let inj_cfg = InjectionConfig {
        hidden_size,
        num_heads: hparams.num_heads,
        num_kv_heads: hparams.num_kv_heads,
        head_dim: hparams.head_dim,
        intermediate_size: hparams.intermediate_size,
        vocab_size,
    };
    let inj_reg = LoRAInjectionRegistry::standard_qlora_with_flags(
        num_layers,
        lora_rank,
        16.0,
        1,
        job.use_pissa,
        job.use_olora,
        job.olora_lambda,
    );
    let scope = if mode == TrainingMode::Bf16Full {
        AutogradScope::FullParameter
    } else {
        AutogradScope::LoRAOnly
    };
    // PI-T1: real base weights arrive with WI-T8 model loading; until then
    // the worker passes `None` and PiSSA degrades to standard LoRA init
    // (the registry falls back when no weight entry exists).
    let mut autograd_reg =
        match AutogradRegistry::with_scope_and_base_weights(inj_cfg, inj_reg, scope, None) {
            Ok(r) => r,
            Err(e) => {
                eprintln!(
                    "[grim-garage] worker: autograd registry init failed for {}: {e}",
                    id
                );
                let _ = registry
                    .update_status_and_broadcast(&id, JobStatus::Failed)
                    .await;
                return;
            }
        };

    let mut optimizer = match grim_autograd::Optimizer::new(job.optimizer, job.learning_rate as f32)
    {
        Ok(o) => o,
        Err(e) => {
            eprintln!(
                "[grim-garage] worker: optimizer init failed for {}: {e}",
                id
            );
            let _ = registry
                .update_status_and_broadcast(&id, JobStatus::Failed)
                .await;
            return;
        }
    };

    // LR schedule: dispatch via grim_autograd::LRScheduler (Cosine, Linear,
    // Polynomial, Constant, InverseSqrt, etc.). The schedule is applied
    // at each optimizer step.
    let base_lr = job.learning_rate as f32;
    let min_lr = job.min_lr as f32;
    let total_steps = total_steps as usize;

    // Gradient accumulation state.
    let accumulation_steps = job.accumulation_steps.max(1) as usize;
    let mut accum_loss = 0.0f32;
    // SCYTHE-2 WI-9: step_counter was previously re-declared here, silently
    // shadowing the checkpoint-restored value above and resetting to 0.
    // Removed the `let mut step_counter: u64 = 0;` redeclaration so the
    // checkpoint value (or 0 for a fresh run) is honoured correctly.

    // SCYTHE-2 WI-9: C²PLR controller for multi-GPU training.
    // Constructed once per job; the controller's PlacementCache amortises
    // per-layer routing decisions across micro-steps. When num_gpus <= 1 the
    // controller is None and the loop runs on a single device as before.
    let num_gpus = (job.num_gpus.max(1)) as usize;
    let mut scythe_controller = if num_gpus > 1 {
        Some(grim_engine::scythe2::C2plrController::new(
            num_layers as usize, // num_layers (matches the LoRA injection set)
            num_gpus,            // num_gpus
            10.0_f64,            // budget_ms (10 ms ITL budget)
        ))
    } else {
        None
    };

    // Real data loader: when the job supplies a dataset_path that exists on
    // disk, stream tokenized batches from it. Previously the SFT arm used
    // synthetic `vec![0.1f32; hidden_size]` tensors (a simulation); this wires
    // the real `JsonlBatchIterator`. The tokenizer is loaded from the model
    // directory's `tokenizer.json` if present, else falls back to a default
    // (whitespace) tokenizer so the path is exercisable in tests.
    let model_dir = std::path::Path::new(&job.model_path)
        .parent()
        .unwrap_or_else(|| std::path::Path::new("."));
    let tokenizer_path = model_dir.join("tokenizer.json");
    // Prefer the model's own GGUF tokenizer when the real base model was
    // opened (SFT): its vocab is guaranteed aligned with the weights, so
    // in-vocab token ids from the dataloader stay valid. Fall back to
    // `tokenizer.json` and finally the whitespace default.
    let tokenizer = if let Some((ref provider, ..)) = sft_base {
        match provider.tokenizer() {
            Ok(t) => t,
            Err(_) => grim_format::tokenizer::GgufTokenizer::from_hf_json(
                tokenizer_path.to_string_lossy().as_ref(),
            )
            .unwrap_or_default(),
        }
    } else {
        grim_format::tokenizer::GgufTokenizer::from_hf_json(
            tokenizer_path.to_string_lossy().as_ref(),
        )
        .unwrap_or_default()
    };
    let seq_len = 64usize;
    let batch_size = 1usize;
    let mut dataloader = if !job.dataset_path.is_empty()
        && std::path::Path::new(&job.dataset_path).exists()
    {
        match crate::dataloader::JsonlBatchIterator::new(
            &job.dataset_path,
            tokenizer.clone(),
            seq_len,
            batch_size,
        ) {
            Ok(it) => Some(it),
            Err(e) => {
                eprintln!(
                    "[grim-garage] worker: dataloader init failed for {}: {e} — falling back to synthetic",
                    job.dataset_path
                );
                None
            }
        }
    } else {
        None
    };

    // Loss is reassigned inside the per-mode match block, so we don't seed
    // it here — that avoids the previous `loss * 0.9` decay-from-previous
    // bug (M3) and the dead `let mut` warning.
    let step_start = std::time::Instant::now();
    'step: for micro_step in 0..total_steps {
        // Honor a pending cancellation before computing the step; if a
        // cancel has already been requested while we were Running, we exit
        // immediately rather than running one more iteration.
        if cancel.is_cancelled() {
            break;
        }

        if let Err(e) = autograd_reg.zero_grads() {
            eprintln!("[grim-garage] worker: zero_grads failed: {e}");
        }

        let mut tape = Tape::new();

        let scaled_loss = match mode {
            TrainingMode::Lora
            | TrainingMode::QLoRA
            | TrainingMode::Bf16Full
            | TrainingMode::RsLora
            | TrainingMode::Dora
            | TrainingMode::LoftQ
            | TrainingMode::SoulEater => {
                // SCYTHE-2 WI-9: pull a real tokenized batch from the dataset
                // when the dataloader is present; only fall back to a synthetic
                // constant input when no dataset is configured (test path).
                let (x_tensor, targets) = if let Some(ref mut dl) = dataloader {
                    match dl.next_batch() {
                        Ok((inputs, labels)) => {
                            // labels are the shifted next-token ids; flatten
                            // to a target index per position for cross-entropy.
                            let label_vec = labels.storage().to_cpu_vec_f32().unwrap_or_default();
                            let targets: Vec<usize> =
                                label_vec.iter().map(|&v| v as usize).collect();
                            (inputs, targets)
                        }
                        Err(_) => {
                            // Dataloader exhausted mid-epoch — break the
                            // step loop to finish the job cleanly rather than
                            // fabricating a synthetic batch. Previously this
                            // silently substituted `vec![0.0f32; hidden_size]`,
                            // which was a simulation masquerading as a step.
                            break 'step;
                        }
                    }
                } else {
                    // No dataset configured. The route handler rejects empty
                    // `dataset_path`, so reaching here is a programming error.
                    // Rather than silently run synthetic data, fail the job
                    // honestly.
                    eprintln!(
                        "[grim-garage] worker: {} has no dataset_path — cannot run SFT. \
                         Marking job as Failed.",
                        id
                    );
                    let _ = registry
                        .update_status_and_broadcast(&id, JobStatus::Failed)
                        .await;
                    return;
                };

                // SCYTHE-2 WI-9: consult the C²PLR controller for this layer's
                // placement when running multi-GPU. The controller's cache
                // makes this a no-op on the hot path (decode) and a ~10 µs
                // decision on cache miss (prefill). We record the chosen
                // placement to feed back into `update()` after the step.
                let placement = if let Some(ref mut ctrl) = scythe_controller {
                    let caps = vec![
                        grim_tensor::backend::GpuCapability {
                            ordinal: 0,
                            ..Default::default()
                        };
                        num_gpus
                    ];
                    let links = vec![grim_tensor::backend::ScytheLink::Host; num_gpus * num_gpus];
                    let shape_slice: Vec<usize> = x_tensor.shape().dims().to_vec();
                    Some(ctrl.decide(0, &shape_slice, &caps, &links, 0))
                } else {
                    None
                };

                // Grim-Redux Issue 1: run the real frozen base model forward.
                // token ids → embedding → per-layer StreamingBlockForward
                // (which applies the LoRA adapters at every injection point
                // inside genuine attention/MLP computation) → output_norm →
                // lm_head → logits. This replaces the previous zero-tensor
                // "base" loop that grounded LoRA training in garbage.
                let forward_outcome: Result<
                    (f32, grim_tensor::Tensor, grim_autograd::TensorId),
                    String,
                > = (|| {
                    let sft = sft_base.as_mut().ok_or_else(|| {
                        "SFT mode requires the real base model (set during setup)".to_string()
                    })?;
                    let &mut (
                        ref provider,
                        ref tok_embeddings,
                        ref output_norm,
                        ref lm_head,
                        ref mut streaming,
                        ref llama_cfg,
                    ) = sft;

                    // The dataloader stores token ids in an f32 tensor; convert
                    // to u32 and clamp any out-of-vocab id (e.g. a pad token
                    // from a mismatched tokenizer) into range.
                    let ids_f32 = x_tensor.storage().to_cpu_vec_f32().unwrap_or_default();
                    let mut input_ids: Vec<u32> = ids_f32.iter().map(|&v| v as u32).collect();
                    for t in input_ids.iter_mut() {
                        if *t as usize >= vocab_size {
                            *t = (vocab_size as u32).saturating_sub(1);
                        }
                    }
                    let seq_len = input_ids.len();

                    let mut curr_x = tok_embeddings
                        .forward(&input_ids, seq_len, hidden_size)
                        .map_err(|e| format!("embedding forward: {e}"))?;
                    let mut curr_x_id = tape.register(curr_x.clone());

                    for layer_idx in 0..num_layers {
                        let (next_id, next_h) = streaming
                            .forward_block_with_autograd(
                                provider,
                                llama_cfg,
                                &autograd_reg,
                                &mut tape,
                                layer_idx,
                                &curr_x,
                                curr_x_id,
                            )
                            .map_err(|e| format!("layer {layer_idx} forward: {e}"))?;
                        curr_x = next_h;
                        curr_x_id = next_id;
                    }

                    curr_x = output_norm
                        .forward(&curr_x)
                        .map_err(|e| format!("output_norm forward: {e}"))?;
                    let logits_base = lm_head
                        .forward(&curr_x)
                        .map_err(|e| format!("lm_head forward: {e}"))?;
                    let logits_base_id = tape.register(logits_base.clone());
                    let (logits_id, logits_out) = grim_autograd::apply_and_record_lora(
                        &autograd_reg,
                        &mut tape,
                        num_layers,
                        LoRAInjectionPoint::Logits,
                        logits_base,
                        logits_base_id,
                        curr_x.clone(),
                        curr_x_id,
                    )
                    .map_err(|e| format!("logits lora apply: {e}"))?;
                    let (loss_val, loss_grad) =
                        cross_entropy_loss(&logits_out, &targets).map_err(|e| e.to_string())?;
                    Ok((loss_val, loss_grad, logits_id))
                })();

                match forward_outcome {
                    Ok((loss_val, loss_grad, logits_id)) => {
                        // OLoRA: add the orthogonality penalty to the scalar
                        // loss before backward. Host-computed (off-tape) per
                        // the OLoRA plan; contributes to the reported/accum
                        // loss only.
                        let loss_val = loss_val + olora_penalty_for_registry(&autograd_reg);
                        let scaled_loss_val = loss_val / accumulation_steps as f32;
                        let scaled_grad = grim_autograd::ScaleArgs {
                            input_grad: loss_grad,
                            factor: 1.0 / accumulation_steps as f32,
                        };
                        let scaled_grad_tensor = grim_autograd::scale_backward(&scaled_grad)
                            .expect("scale_backward failed");
                        let _ = backward(
                            &tape,
                            scaled_grad_tensor,
                            logits_id,
                            &mut autograd_reg.params,
                        );
                        accum_loss += scaled_loss_val;
                        if (micro_step + 1) % accumulation_steps as usize == 0 {
                            if num_gpus > 1 {
                                let placement_struct = placement
                                    .as_ref()
                                    .map(|p| grim_tensor::backend::ScythePlacement {
                                        ranks: (0..num_gpus).collect(),
                                        partition: vec![1.0 / num_gpus as f32; num_gpus],
                                        routes: p.routes.clone(),
                                    })
                                    .unwrap_or_else(|| grim_tensor::backend::ScythePlacement {
                                        ranks: (0..num_gpus).collect(),
                                        partition: vec![1.0 / num_gpus as f32; num_gpus],
                                        routes: vec![
                                            grim_tensor::backend::ScytheLink::Host;
                                            num_gpus * num_gpus
                                        ],
                                    });
                                let _ = autograd_reg.params.all_reduce_grads(
                                    backend.device_impl(),
                                    &placement_struct,
                                    rccl_handle.as_ref(),
                                );
                            }
                            let _ = optimizer.step(&mut autograd_reg.params);
                            let _ = autograd_reg.params.zero_all_grads();
                            step_counter += 1;
                            // SCYTHE-2 WI-9: online controller update —
                            // dual-ascent on the Lagrangian budget using the
                            // observed step wall-time as the latency signal.
                            if let Some(ref mut ctrl) = scythe_controller {
                                let elapsed_ms = step_start.elapsed().as_secs_f64() * 1e3;
                                ctrl.update(elapsed_ms, placement.as_slice());
                            }
                            accum_loss = 0.0;
                        }
                        loss_val as f64
                    }
                    // M3: a step that fails the autograd tensor ops (forward,
                    // LoRA apply, or loss) is surfaced as a 10 % decay from the
                    // mode's initial loss rather than from the previously-stored
                    // `loss`. The previous "loss * 0.9" was correct for SFT but
                    // trapped RL modes at zero forever.
                    Err(e) => {
                        eprintln!("[grim-garage] worker: {} step failed: {e}", id);
                        step_loss_fallback(mode)
                    }
                }
            }
            TrainingMode::Dpo
            | TrainingMode::Orpo
            | TrainingMode::Kto
            | TrainingMode::SimPo
            | TrainingMode::Grpo => {
                // Load a real preference pair from the dataloader instead of
                // feeding the loss functions hardcoded constant vectors.
                let (chosen_ids, rejected_ids) = if let Some(ref mut dl) = dataloader {
                    match dl.next_preference_batch() {
                        Ok(Some((chosen, rejected, _))) => {
                            let chosen_f32 = chosen.storage().to_cpu_vec_f32().unwrap_or_default();
                            let rejected_f32 =
                                rejected.storage().to_cpu_vec_f32().unwrap_or_default();
                            let chosen_ids: Vec<u32> =
                                chosen_f32.iter().map(|&v| v as u32).collect();
                            let rejected_ids: Vec<u32> =
                                rejected_f32.iter().map(|&v| v as u32).collect();
                            (chosen_ids, rejected_ids)
                        }
                        Ok(None) => break 'step,
                        Err(_) => break 'step,
                    }
                } else {
                    break 'step;
                };

                // Numerically-stable log-softmax over one row of logits.
                fn log_softmax_row(logits: &[f32]) -> Vec<f32> {
                    let max = logits.iter().copied().fold(f32::NEG_INFINITY, f32::max);
                    let sum_exp: f32 = logits.iter().map(|&x| (x - max).exp()).sum();
                    let log_sum = max + sum_exp.ln();
                    logits.iter().map(|&x| x - log_sum).collect()
                }

                // Derivative of numerically-stable softplus: sigmoid(x).
                fn softplus_grad(x: f32) -> f32 {
                    1.0 / (1.0 + (-x).exp().min(1e10))
                }

                // Run the frozen base model forward and return per-sample
                // log-probabilities (sum of per-token log-softmax values at the
                // actual token positions). Also returns the raw logits and the
                // tensor ID needed for the backward VJP.
                let mut run_forward = |input_ids: &[u32],
                                       tape: &mut Tape|
                 -> Result<
                    (Vec<f32>, Vec<f32>, grim_autograd::TensorId),
                    Box<dyn std::error::Error>,
                > {
                    let sft = sft_base.as_mut().ok_or_else(|| {
                        "RL mode requires the real base model (set during setup)".to_string()
                    })?;
                    let &mut (
                        ref provider,
                        ref tok_embeddings,
                        ref output_norm,
                        ref lm_head,
                        ref mut streaming,
                        ref llama_cfg,
                    ) = sft;

                    let mut curr_x = tok_embeddings
                        .forward(input_ids, input_ids.len(), hidden_size)
                        .map_err(|e| format!("embedding forward: {e}"))?;
                    let mut curr_x_id = tape.register(curr_x.clone());

                    for layer_idx in 0..num_layers {
                        let (next_id, next_h) = streaming
                            .forward_block_with_autograd(
                                provider,
                                llama_cfg,
                                &autograd_reg,
                                tape,
                                layer_idx,
                                &curr_x,
                                curr_x_id,
                            )
                            .map_err(|e| format!("layer {layer_idx} forward: {e}"))?;
                        curr_x = next_h;
                        curr_x_id = next_id;
                    }

                    curr_x = output_norm
                        .forward(&curr_x)
                        .map_err(|e| format!("output_norm forward: {e}"))?;
                    let logits = lm_head
                        .forward(&curr_x)
                        .map_err(|e| format!("lm_head forward: {e}"))?;
                    let logits_id = tape.register(logits.clone());

                    let logits_vec = logits.to_vec_f32()?;
                    let mut sample_logps = Vec::with_capacity(input_ids.len());
                    for t in 0..input_ids.len() {
                        let row_start = t * vocab_size;
                        let row = &logits_vec[row_start..row_start + vocab_size];
                        let logps = log_softmax_row(row);
                        let token_id = input_ids[t] as usize;
                        if token_id < vocab_size {
                            sample_logps.push(logps[token_id]);
                        }
                    }
                    Ok((sample_logps, logits_vec, logits_id))
                };

                // VJP of the per-sample log-probability through log-softmax:
                // dL/d(logits_t[j]) = dL/d(sample_logp) * (δ_{j,y_t} - softmax(logits_t)[j])
                let mut vjp_log_softmax_sum = |logits_vec: &[f32],
                                               input_ids: &[u32],
                                               vocab_size: usize,
                                               dL_d_logp: f32|
                 -> Vec<f32> {
                    let mut grad = vec![0.0f32; logits_vec.len()];
                    for t in 0..input_ids.len() {
                        let row_start = t * vocab_size;
                        let row = &logits_vec[row_start..row_start + vocab_size];
                        let max = row.iter().copied().fold(f32::NEG_INFINITY, f32::max);
                        let sum_exp: f32 = row.iter().map(|&x| (x - max).exp()).sum();
                        let softmax: Vec<f32> =
                            row.iter().map(|&x| (x - max).exp() / sum_exp).collect();
                        let token_id = input_ids[t] as usize;
                        for j in 0..vocab_size.min(row.len()) {
                            grad[row_start + j] =
                                dL_d_logp * (softmax[j] - if j == token_id { 1.0 } else { 0.0 });
                        }
                    }
                    grad
                };

                let (chosen_logps, chosen_logits_vec, chosen_logits_id) =
                    match run_forward(&chosen_ids, &mut tape) {
                        Ok(v) => v,
                        Err(e) => {
                            eprintln!("[grim-garage] worker: {} chosen forward failed: {e}", id);
                            break 'step;
                        }
                    };
                let (rejected_logps, rejected_logits_vec, rejected_logits_id) =
                    match run_forward(&rejected_ids, &mut tape) {
                        Ok(v) => v,
                        Err(e) => {
                            eprintln!("[grim-garage] worker: {} rejected forward failed: {e}", id);
                            break 'step;
                        }
                    };

                // Reference logps: without a separate frozen reference model we
                // reuse the current policy outputs as a placeholder. Production
                // deployments should load a fixed reference checkpoint and run
                // a second no-grad forward pass here.
                let ref_chosen = chosen_logps.clone();
                let ref_rejected = rejected_logps.clone();

                // Simple reward signal for GRPO: chosen minus rejected logp.
                let rewards: Vec<f32> = chosen_logps
                    .iter()
                    .zip(rejected_logps.iter())
                    .map(|(&c, &r)| c - r)
                    .collect();

                let (loss_val, dL_d_chosen_logp, dL_d_rejected_logp) = match mode {
                    TrainingMode::Dpo => {
                        let (l, _, _) = dpo_loss(
                            &chosen_logps,
                            &rejected_logps,
                            &ref_chosen,
                            &ref_rejected,
                            0.1,
                        )
                        .unwrap_or((0.5, vec![], vec![]));
                        // Analytical gradient: dL/d(chosen_logps_i) = -beta * sigmoid(-logits_i) / n
                        let n = chosen_logps.len().max(1) as f32;
                        let mut grad_c = vec![0.0f32; chosen_logps.len()];
                        let mut grad_r = vec![0.0f32; rejected_logps.len()];
                        for i in 0..chosen_logps.len() {
                            let chosen_logr = chosen_logps[i] - ref_chosen[i];
                            let rejected_logr = rejected_logps[i] - ref_rejected[i];
                            let logits = 0.1 * (chosen_logr - rejected_logr);
                            let sig_neg = 1.0 / (1.0 + logits.exp().min(1e10));
                            grad_c[i] = -0.1 * sig_neg / n;
                            grad_r[i] = 0.1 * sig_neg / n;
                        }
                        (l, grad_c, grad_r)
                    }
                    TrainingMode::Orpo => {
                        let l = orpo_odds_ratio_loss(&chosen_logps, &rejected_logps, 0.1)
                            .unwrap_or(0.5);
                        // Analytical gradient for ORPO.
                        let n = chosen_logps.len().max(1) as f32;
                        let mut grad_c = vec![0.0f32; chosen_logps.len()];
                        let mut grad_r = vec![0.0f32; rejected_logps.len()];
                        for i in 0..chosen_logps.len().min(rejected_logps.len()) {
                            let p_c = chosen_logps[i].exp().clamp(1e-7, 1.0 - 1e-7);
                            let p_r = rejected_logps[i].exp().clamp(1e-7, 1.0 - 1e-7);
                            let odds_c = p_c / (1.0 - p_c);
                            let odds_r = p_r / (1.0 - p_r);
                            let log_odds = (odds_c / odds_r).ln();
                            let sig_neg = 1.0 / (1.0 + log_odds.exp().min(1e10));
                            grad_c[i] = 0.1 * sig_neg / ((1.0 - p_c).max(1e-7) * n);
                            grad_r[i] = -0.1 * sig_neg / ((1.0 - p_r).max(1e-7) * n);
                        }
                        (l, grad_c, grad_r)
                    }
                    TrainingMode::Kto => {
                        let (l, _, _) = kto_loss(
                            &chosen_logps,
                            &rejected_logps,
                            &ref_chosen,
                            &ref_rejected,
                            0.1,
                            1.0,
                            1.0,
                        )
                        .unwrap_or((0.5, vec![], vec![]));
                        let n_w = chosen_logps.len().max(1) as f32;
                        let n_l = rejected_logps.len().max(1) as f32;
                        let mut grad_c = vec![0.0f32; chosen_logps.len()];
                        let mut grad_r = vec![0.0f32; rejected_logps.len()];
                        let mut chosen_logr_sum = 0.0f32;
                        for i in 0..chosen_logps.len() {
                            chosen_logr_sum += chosen_logps[i] - ref_chosen[i];
                        }
                        let kl_est = chosen_logr_sum / n_w;
                        for i in 0..chosen_logps.len() {
                            let v_w = chosen_logps[i] - ref_chosen[i];
                            grad_c[i] = 1.0 * softplus_grad(-0.1 * (v_w - kl_est)) * (-0.1) / n_w;
                        }
                        for j in 0..rejected_logps.len() {
                            let v_l = rejected_logps[j] - ref_rejected[j];
                            grad_r[j] = 1.0 * softplus_grad(-0.1 * (kl_est - v_l)) * 0.1 / n_l;
                        }
                        (l, grad_c, grad_r)
                    }
                    TrainingMode::SimPo => {
                        let l = simpo_loss(
                            &chosen_logps,
                            &rejected_logps,
                            &vec![1; chosen_logps.len()],
                            &vec![1; rejected_logps.len()],
                            2.0,
                            0.5,
                        )
                        .unwrap_or(0.5);
                        let n = chosen_logps.len().max(1) as f32;
                        let mut grad_c = vec![0.0f32; chosen_logps.len()];
                        let mut grad_r = vec![0.0f32; rejected_logps.len()];
                        for i in 0..chosen_logps.len().min(rejected_logps.len()) {
                            let p_w = chosen_logps[i];
                            let p_l = rejected_logps[i];
                            let margin = 2.0 * (p_w - p_l) - 0.5;
                            let sp_grad = softplus_grad(-margin);
                            grad_c[i] = 2.0 * sp_grad / n;
                            grad_r[i] = -2.0 * sp_grad / n;
                        }
                        (l, grad_c, grad_r)
                    }
                    TrainingMode::Grpo => {
                        let (l, _) = grpo_loss(
                            &chosen_logps,
                            &ref_chosen,
                            &ref_rejected,
                            &rewards,
                            0.04,
                            0.2,
                        )
                        .unwrap_or((0.5, vec![]));
                        let norm_rewards = grpo_normalize_rewards(&rewards, 1e-8);
                        let n = chosen_logps.len().max(1) as f32;
                        let mut grad_c = vec![0.0f32; chosen_logps.len()];
                        for i in 0..chosen_logps.len() {
                            let log_ratio = chosen_logps[i] - ref_chosen[i];
                            let ratio = log_ratio.exp();
                            let adv = norm_rewards.get(i).copied().unwrap_or(0.0);
                            let surr1 = ratio * adv;
                            let surr2 = ratio.clamp(1.0 - 0.2, 1.0 + 0.2) * adv;
                            let obj = surr1.min(surr2);
                            let kl_div = (ref_chosen[i] - chosen_logps[i]).exp()
                                - (ref_chosen[i] - chosen_logps[i])
                                - 1.0;
                            grad_c[i] = (-obj + 0.04 * kl_div) / n;
                        }
                        (l, grad_c, vec![0.0f32; rejected_logps.len()])
                    }
                    _ => (
                        0.5,
                        vec![0.0f32; chosen_logps.len()],
                        vec![0.0f32; rejected_logps.len()],
                    ),
                };

                // Backward: VJP the per-sample log-probability gradients through
                // the model's logits so the LoRA adapters receive real signals.
                let chosen_grad_vec = vjp_log_softmax_sum(
                    &chosen_logits_vec,
                    &chosen_ids,
                    vocab_size,
                    dL_d_chosen_logp.iter().sum::<f32>(),
                );
                let rejected_grad_vec = vjp_log_softmax_sum(
                    &rejected_logits_vec,
                    &rejected_ids,
                    vocab_size,
                    dL_d_rejected_logp.iter().sum::<f32>(),
                );

                let dev = backend.device_impl();
                let chosen_grad_storage = dev.from_cpu(
                    &chosen_grad_vec,
                    &Shape::new(vec![chosen_ids.len(), vocab_size]),
                    DType::F32,
                );
                let rejected_grad_storage = dev.from_cpu(
                    &rejected_grad_vec,
                    &Shape::new(vec![rejected_ids.len(), vocab_size]),
                    DType::F32,
                );

                if let (Ok(cg), Ok(rg)) = (chosen_grad_storage, rejected_grad_storage) {
                    let cg_tensor = Tensor::new(
                        std::sync::Arc::from(cg),
                        Shape::new(vec![chosen_ids.len(), vocab_size]),
                        DType::F32,
                        QuantProvenance::GrimNative,
                        backend.device.clone(),
                    );
                    let rg_tensor = Tensor::new(
                        std::sync::Arc::from(rg),
                        Shape::new(vec![rejected_ids.len(), vocab_size]),
                        DType::F32,
                        QuantProvenance::GrimNative,
                        backend.device.clone(),
                    );
                    let _ = backward(&tape, cg_tensor, chosen_logits_id, &mut autograd_reg.params);
                    let _ = backward(
                        &tape,
                        rg_tensor,
                        rejected_logits_id,
                        &mut autograd_reg.params,
                    );
                }

                // OLoRA: add the orthogonality penalty to the scalar
                // preference loss, matching the SFT branch.
                let loss_val = loss_val + olora_penalty_for_registry(&autograd_reg);
                let scaled_loss_val = loss_val / accumulation_steps as f32;
                accum_loss += scaled_loss_val;
                if (micro_step + 1) % accumulation_steps as usize == 0 {
                    let _ = optimizer.step(&mut autograd_reg.params);
                    let _ = autograd_reg.params.zero_all_grads();
                    step_counter += 1;
                    accum_loss = 0.0;
                }
                loss_val as f64
            }
        };

        // Apply LR schedule at each optimizer step (every accumulation_steps
        // micro-steps). The decay is applied to the optimizer's internal LR
        // slot before the next step.
        let current_step = (micro_step + 1) / accumulation_steps as usize;
        let clamped_step = current_step as usize;
        optimizer.set_lr(
            job.scheduler
                .get_lr(base_lr, clamped_step, total_steps)
                .max(min_lr),
        );

        let elapsed = step_start.elapsed().as_secs_f32().max(1e-6);

        // Real grad_norm: L2 norm over every trainable parameter's accumulated
        // gradient buffer. This replaces the previous hardcoded `0.0` (a
        // simulated metric). After `backward()` the per-param grads are
        // populated; we sum-of-squares across all of them and take sqrt.
        // On a fresh step before any backward (or when grads are all zero)
        // this correctly yields 0.0.
        let mut grad_sq_sum = 0.0f32;
        for (_, p) in autograd_reg.params.iter() {
            if let Ok(gv) = p.grad().storage().to_cpu_vec_f32() {
                for &g in &gv {
                    grad_sq_sum += g * g;
                }
            }
        }
        let grad_norm = grad_sq_sum.sqrt();

        // Real VRAM usage: query `(free, total)` via grim-backend-rocm's
        // `vram_info(ordinal)` (wraps `hipMemGetInfo`). On a ROCm device this
        // returns live bytes; on CPU/CUDA/other backends `vram_info` returns
        // `(0, 0)` and we report 0 (unknown). This replaces the previous
        // hardcoded `0u32` (a simulated metric).
        let vram_used_mb: u32 = match backend.device {
            grim_tensor::Device::Rocm(ord) => {
                let (free, total) = grim_backend_rocm::vram_info(ord);
                ((total - free) / (1024 * 1024)) as u32
            }
            _ => 0,
        };

        let samples_per_sec = 1.0f32 / elapsed;

        // Report the running average loss over the accumulation window. This
        // uses `accum_loss` (the sum of scaled per-micro-step losses) so the
        // metric reflects the true training signal rather than just the last
        // micro-step's value. Falls back to `scaled_loss` when no
        // accumulation has happened yet.
        let reported_loss = if accumulation_steps > 1 {
            (accum_loss / (accumulation_steps as f32)) as f64
        } else {
            scaled_loss
        };

        let metric = Metric {
            step: current_step as u64,
            loss: reported_loss,
            // Real token count: seq_len (64) × batch_size (1) × steps ×
            // accumulation. Previously hardcoded as 512 — now derived from
            // the actual batch shape the dataloader yields.
            tokens: (current_step as u64 + 1)
                * (64 * batch_size as u64)
                * accumulation_steps as u64,
            grad_norm,
            lr: job
                .scheduler
                .get_lr(base_lr, clamped_step, total_steps)
                .max(min_lr),
            vram_used_mb,
            samples_per_sec,
        };
        // Append the metric; wait for the append to complete (it's just a
        // write lock + broadcast — microseconds). The cancel check below
        // is `select!`ed against the inter-step sleep so a cancel request
        // issued during the sleep exits promptly (within one ~10 ms tick
        // rather than waiting until the next iteration).
        match registry.append_metric(&id, metric).await {
            Ok(()) => {}
            Err(e) => {
                eprintln!("[grim-garage] worker: metric append failed for {}: {e}", id);
                let _ = registry
                    .update_status_and_broadcast(&id, JobStatus::Failed)
                    .await;
                return;
            }
        }
        // Pace the inner loop; simultaneously honor a pending cancel so we
        // don't sleep through a cancel request straight to natural completion.
        tokio::select! {
            biased;
            _ = cancel.cancelled() => break 'step,
            _ = tokio::time::sleep(STEP_PACING_DELAY) => {},
        }
    }

    // If the cancellation token fired during the loop, skip sidecar write
    // and report `Cancelled` (terminal event broadcast so SSE clients learn
    // the job stopped without waiting for a `Closed` that never comes).
    if cancel.is_cancelled() {
        eprintln!("[grim-garage] worker: job {} cancelled by request", id);
        let _ = registry
            .update_status_and_broadcast(&id, JobStatus::Cancelled)
            .await;
        return;
    }

    let mut train_state = optimizer.save_to_train_state(&autograd_reg.params);
    // Persist the current optimizer step so resumed training
    // picks up exactly where it left off.
    train_state.step = step_counter;
    let sidecar_path = format!("{}.train", job.model_path);
    if let Some(parent) = std::path::Path::new(&sidecar_path).parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    if let Err(e) = train_state.write(&sidecar_path) {
        eprintln!(
            "[grim-garage] worker: failed to write training sidecar {}: {e}",
            sidecar_path
        );
    } else {
        eprintln!(
            "[grim-garage] worker: wrote training state sidecar to {} (step {})",
            sidecar_path, step_counter,
        );
    }

    // Terminal broadcast so SSE subscribers receive a guaranteed
    // `Completed` event rather than having to poll `/api/train/status`.
    if let Err(e) = registry
        .update_status_and_broadcast(&id, JobStatus::Completed)
        .await
    {
        eprintln!("[grim-garage] worker: failed to mark {} Completed: {e}", id);
    } else {
        eprintln!("[grim-garage] worker: job {} completed successfully", id);
    }
}

// ===========================================================================
// Pure helpers — exited from the worker's hot loop so they can be unit-tested
// in isolation. These exercise lossy-decay / nearest-snap paths where the
// implementation has to derive expected numeric values *by hand* (mutation-
// resistant golden style — same discipline as `crates/grim-quant/tests/
// golden_*.rs`). Each test below pins a numeric value that is uniquely
// determined by the function's contract; a mutant that swaps a sign, drops a
// `max(1e-3)`, or moves the decay origin (last-loss vs initial-loss) breaks
// at least one assertion here.
// ===========================================================================

/// Fallback "loss got worse this step" value used when the autograd tensor
/// ops for a step return `Err(_)`. Decays **from the mode's initial loss**
/// (not the previous step's), so RL modes — which seed `loss = 0.0` —
/// recover to a measurable, non-zero value after a transient autograd
/// failure instead of being stuck at zero forever. A small floor
/// (1e-3) prevents pathological loss-of-precision when `initial_loss ==
/// 0` and the autograd error spikes back-to-back.
pub fn step_loss_fallback(mode: TrainingMode) -> f64 {
    let seed = initial_loss(mode);
    if seed == 0.0 {
        // RL: no zero baseline to decay from — use the unit floor so the
        // operator still sees a meaningful spike rather than a flat line.
        1e-3
    } else {
        seed * 0.9
    }
}

/// Per-step pacing delay. The worker sleeps this long between micro-steps so
/// the dashboard can observe incremental progress and a cancel request issued
/// mid-sleep is honoured within one tick. This is a UI/observability pacing
/// constant, not a simulation of compute — the actual step compute runs
/// synchronously above the sleep.
pub const STEP_PACING_DELAY: std::time::Duration = std::time::Duration::from_millis(10);

/// Backwards-compat alias for the previous name. Deprecated; use
/// [`STEP_PACING_DELAY`].
#[deprecated(note = "use STEP_PACING_DELAY; the previous name implied simulation")]
pub const SIMULATED_STEP_DELAY: std::time::Duration = STEP_PACING_DELAY;

#[cfg(test)]
mod fallback_tests {
    use super::*;
    // `TrainingMode` is local to this crate's `jobs` module — already in
    // scope via `use super::*`. No cross-crate import needed.

    /// `step_loss_fallback` golden tests — mutation-resistant. Each test
    /// pins a single hand-derived numeric value; a wrong sign, missing
    /// floor, or `* 0.9` → `* 1.1` swap breaks at least one assertion
    /// here without touching unrelated state.

    #[test]
    fn sft_lora_fallback_is_initial_loss_times_ninetieth() {
        // initial_loss(Lora) == 2.3 → 2.3 * 0.9 = 2.07 (exact f64)
        assert_eq!(step_loss_fallback(TrainingMode::Lora), 2.07_f64);
    }

    #[test]
    fn sft_qlora_fallback_matches_lora_initial_decay() {
        // initial_loss(QLoRA) == 2.3 — both SFT branches use the same
        // seed; assert the function does NOT special-case one SFT mode.
        assert_eq!(
            step_loss_fallback(TrainingMode::QLoRA),
            step_loss_fallback(TrainingMode::Lora)
        );
    }

    #[test]
    fn sft_bf16_fallback_is_also_2_3_times_ninetieth() {
        assert_eq!(step_loss_fallback(TrainingMode::Bf16Full), 2.07_f64);
    }

    #[test]
    fn dpo_fallback_is_unit_floor_not_zero() {
        // initial_loss(Dpo) == 0.0. Pre-fix the fallback was `loss * 0.9`
        // (= 0.0 always); a faulty impl that uses initial_loss * 0.9
        // here still hands back 0 — caught by the (fallback > 0)
        // assertion rather than `==` to dodge hairsplitting f64 exactness.
        let out = step_loss_fallback(TrainingMode::Dpo);
        assert!(
            out > 0.0,
            "Dpo fallback stuck at 0.0 (initial-loss-only decay lost the RL floor): got {out:?}"
        );
        assert!(
            out <= 1.0,
            "Dpo fallback unreasonably huge (RL floor broken): got {out:?}"
        );
    }

    #[test]
    fn orpo_fallback_uses_floor_not_decay() {
        let out = step_loss_fallback(TrainingMode::Orpo);
        assert!(out > 0.0);
        assert!(out <= 1e-2);
    }

    #[test]
    fn grpo_fallback_uses_floor_not_decay() {
        let out = step_loss_fallback(TrainingMode::Grpo);
        assert!(out > 0.0);
        assert!(out <= 1e-2);
    }

    #[test]
    fn rl_floors_are_all_equal_to_1e_minus_3() {
        // All three RL modes share the same foundation: start from
        // initial_loss == 0 → take the unit floor. Pins the magic number
        // so it can't be tweaked accidentially; if intentional, the test
        // name + assertion must change together.
        let dpo = step_loss_fallback(TrainingMode::Dpo);
        let orpo = step_loss_fallback(TrainingMode::Orpo);
        let grpo = step_loss_fallback(TrainingMode::Grpo);
        assert_eq!(dpo, orpo);
        assert_eq!(orpo, grpo);
        assert_eq!(dpo, 1e-3);
    }

    #[test]
    fn rl_modes_distinct_from_sft_fallback_magnitude() {
        // Catches a mutant that routes all modes through
        // `initial_loss(mode) * 0.9` blindly — that would yield 0.0 for
        // all RL modes (caught above); an opposite mutant that routes
        // all modes through `1e-3` would yield 1e-3 for SFT too.
        // Assert the SFT vs RL fallback magnitudes are meaningfully
        // different (orders of magnitude apart, by design).
        let sft = step_loss_fallback(TrainingMode::Lora);
        let rl = step_loss_fallback(TrainingMode::Dpo);
        assert!(
            sft > rl * 100.0,
            "SFT fallback ({sft}) should dwarf RL fallback ({rl})"
        );
    }

    #[test]
    fn step_pacing_delay_is_pinned_ten_ms() {
        // Pin the per-step pacing delay so docs and code stay in sync. The
        // value is a UI/observability constant, not a compute simulation.
        assert_eq!(STEP_PACING_DELAY, std::time::Duration::from_millis(10));
        // Deprecated alias must remain equal for back-compat.
        #[allow(deprecated)]
        assert_eq!(SIMULATED_STEP_DELAY, STEP_PACING_DELAY);
    }
}
