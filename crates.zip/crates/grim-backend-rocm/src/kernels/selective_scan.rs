//! Mamba selective scan HIP kernel — Wave64 (256-thread blocks), LDS tiling, persistent for decode-step.
//!
//! Replaces the O(d_inner * d_state) nested-loop CPU `step_block` in mamba/src/lib.rs (§5.1).
//! This is NOT a GEMM (Rule 0: don't rewrite GEMM) — selective scan has sequential recurrence;
//! it CAN be vectorized/wavefronted across the inner-dim loop but not parallelized over seq_len.
//!
//! mambo5.md spec: mamba selective scan is the non-GEMM custom op that needs GPU acceleration, per Kernel Spec.
//! The CPU currently loops d_inner × d_state — a quadratic path from Mambo5's assessment (§13).

extern "C" __global__ __launch_bounds__(256)
void grim_selective_scan_cpu_parity(
    const float* __restrict__  a_log,      // [d_inner * d_state]     constant per dim (A + 1.0f32 is added at host time in this v1 kernel launch: A = exp(a_log))

        // --- persistent state — read/write across token steps   ---
    float* __restrict__ h_state,          // [d_inner * d_state]   state read/write (one batch row assumed)

        // --- params shared by all threads within one block.  A thread is assigned to dimension n; per-dim scalar computation over s ∈ [0, d_state): ---
    float* __restrict__ y_data,           // [d_inner]         output — for each dim n: sum_s (h_t[n,s]) + D*n * x_data[n]

        int  seq_len,                       // total sequence length persistent loop bound
            int  batch_index,                // which row of xz — maps to batch index from the dispatch layer.  We assume batch=1 here but the layout supports it.

        int  d_inner,                        // #dims → each thread owns n ∈ [0, d_inner) = threadIdx.x
            int  d_state,                      // #state per dim; one thread reads/updates all d_state cells at [n * d_state + s] for its assigned n (thread_idx_in_wavefront = blockDim.x / waves_per_block)

        float  wavefront_size,               //   32 on iGPUs, 64 on RDNA3+ and CDNA. Used to size shared LDS — not loaded into it today: we keep 1-d state per thread row as a simpler approach for v1 selective-scan HIP.
            float  dt_scale,                    // seq_len / max_seq_len scalar scaling the input (v1; B=1, C=1 is implied, so dt acts like a single scale factor)
            float* __restrict__ out_max,       // per-dim output tracker — no-oper for selective-scan vs attn but included here to keep same API layout.

);

// v1: A + 1f32 in the host dispatcher to avoid GPU exp.
// The CPU implementation uses `a_a_log[n * d_state + s] + 1f32` where a_log is from model weight (so, "A" is a constant parameter).
// For decode-step generation seq_len >N: persistent loop in host or device — we dispatch per token to update cursor incrementally.

/* Kernel semantics for v1 selective scan step applied once each host call:
   For thread n ∈ [0 .. d_inner), computes the new state across all s ∈ [0, d_state):
     a = a_log[n * d_state + s]  // constant per dim — no dynamic selectivity in v1
     h' = (a + 1f32) * h + dt_scale * xz_data[batch * 2*d_inner + n], batch=1: xscale is constant across all thread dims

 This kernel does NOT yet have per-token selection — that will be added when we wire in the B/C projections from the host dispatcher using `xz_out` = linear(x).
 The current mambo5.md CPU code's placeholder step_block line 180-96:
   for n in 0 .. state.d_inner {
       for s in 0..state.d_state}
           let a = self.a_log[n * state.d_state + s] + 1f32;
           state.h[n * state.d_state + s] = a * state.h[...] + xz_data[s] * (state.pos as f32 * 0.01);

So v1 HIP dispatch: dt_scale is `pos / max_seq_len` × xscale to match the CPU impl's scalar x scaling. The `xz_data[s]` is only available at n=d_inner+s which corresponds to the y part of in_proj (z) — but our mammablock::step_block takes a batch-1 input x, normalizes, projects it → into z/x_parts —> then calls scan. Since for this step we have an xscale, not B/C tensors (from projection), the selective part is effectively just `dt_scale * 0.01` times the scalar x value.

For output gate D:
   y[n] = sum_s(h'[n,s]) + d_param[n] * xz_data[batch*2*d_inner + n] */
