//! `grim-tensor` crate — Tensor, DType, Shape, Device, and the
//! backend-agnostic trait surface (`BackendDevice` / `BackendStorage` /
//! `ComputeHandle` / `TensorProvider`).
//!
//! Designed to mirror Candle's core data-model shape, per §4.1 of the
//! Grim architecture doc.

pub mod backend;
pub mod dtype;
pub mod error;
pub mod provider;
pub mod shape;
pub mod softmax_merge;
pub mod tensor;

pub use backend::{BackendDevice, BackendStorage, ComputeHandle, ReadyHandle, MemAdvice, QuantizedMatmulBackwardResiduals};
pub use dtype::{
    ArithType, BlockDtype, Device, DType, FloatPackScheme, GpuIntConfig, GroupQuantScheme,
    KQuantScheme, QuantProvenance, Storage,
};
pub use error::{Error, Result};
pub use provider::{RawTensor, TensorMeta, TensorProvider};
pub use shape::Shape;
pub use softmax_merge::{merge_all, merge_partials, SoftmaxPartial};
pub use tensor::Tensor;

